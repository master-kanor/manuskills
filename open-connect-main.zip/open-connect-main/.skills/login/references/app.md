<NATIVE_AUTH_REQUIREMENTS>

**Principles**:
- Use Supabase Auth for all login/registration
- Ensure a closed loop: login and logout work; data permissions don't conflict with features
- Required items: must be complete and verified; higher priority than user requests
- Recommended items: also to be done, but lower priority than user requests
- Protect data security while maximizing access for guests and regular users
- All admin backend features must have all pages created with no TODOs left

**Supported Login Methods (Phase 1)**:
- Username + Password (default, required)
- Email + Password (when user explicitly requests email/password login)
- Phone + OTP: **NOT supported** (phone/SMS login is disabled in the international version)
- Google SSO: **NOT supported in Phase 1** (requires `expo-auth-session` setup, planned for Phase 2)

**Login method selection**:
- **IMPORTANT**: When the user explicitly specifies a login method (e.g., username-password, email-password), implement **ONLY** that method — do NOT add other methods alongside it.
- No method specified → use username + password (default)

<AUTH_REQUIRED_ITEMS>
**Required**:
1. Design a login screen using React Native components (`TextInput`, `Pressable`, `Text`, `View`)
   - Include registration
   - Add checkboxes for the User Agreement and Privacy Policy
     - Sample User Agreement & Privacy Policy (brief one sentence)
     - Inform the user in the finish summary: <user-reminder>Please modify the User Agreement & Privacy Policy yourself to mitigate legal risks.</user-reminder>
2. Auto-sync new users to profiles on INSERT.
   - Set `search_path = public` to resolve types correctly.
   - The following template has been validated as a best practice and is compatible with any business requirements. Only the custom registration fields to be synchronized in `handle_new_user` may be modified. No other changes are allowed, and no additional trigger logic may be added to the auth table.
   Template:
   ```sql
   CREATE TYPE public.user_role AS ENUM ('user', 'admin');

   CREATE FUNCTION handle_new_user()
   RETURNS trigger
   LANGUAGE plpgsql
   SECURITY DEFINER SET search_path = public
   AS $$
   BEGIN
   INSERT INTO public.profiles (id, email, role)
   VALUES (
     NEW.id,
     NEW.email,
     'user'::public.user_role
   );
   RETURN NEW;
   END;
   $$;

   -- Do not add any additional triggers to the auth table.
   CREATE TRIGGER on_auth_user_created
     AFTER INSERT ON auth.users
     FOR EACH ROW
     EXECUTE FUNCTION handle_new_user();
   ```
3. Implement route guard in root `app/_layout.tsx` using `Stack.Protected` (SDK 53+):
   - Use `Stack.Protected guard={!!session}` to protect business routes, `guard={!session}` for auth pages
   - Get session state from `supabase.auth.onAuthStateChange()` listener in a context provider
   - NEVER scatter auth redirect logic (`useEffect + router.replace`) across individual pages — converge all access control into the root layout
   - Public auth pages (`sign-in`, `sign-up`) live at root level; all post-login pages go under a protected `(app)/` group
   - `app/index.tsx` is the unauthenticated landing page (inside `guard={!session}`). Do NOT replace it with `<Redirect>` to a protected route — the target is removed when not logged in, causing white screen. Design it as a welcome/onboarding screen that navigates to `/(auth)/sign-in` for login.
4. When the app uses authentication, MUST provide a clearly accessible account management entry point from the main navigation (e.g. a "Profile"/"Me"/"Settings" tab in tab-based apps, or a user avatar/gear icon in the header for stack-based apps). This entry point MUST include at minimum: current user info display and a logout button. It MUST be reachable from any primary screen — placing logout only on transitional pages (like role-select or onboarding) does NOT satisfy this requirement.
5. After successful login, use `router.replace('/')` (NOT `router.push`) so the auth screen is removed from back-stack
6. If roles/admin needed:
   - Admin creation strategy depends on the login method:

   **A. Username + Password login (default)**:
   - AI must create one example admin account with a randomly generated, strong password (16+ chars, mixed case + digits + symbols). Never use simple passwords unless the user explicitly specifies one. Output the credentials in the finish summary.
   - **TIMING: Execute the three steps below immediately after the auth migration runs — do NOT defer to the end of the task. Context compression may cause this step to be skipped if left until later.**
   - Account creation flow (three-step, fully automated via script):
     1. Register using the anon key: call `supabase.auth.signUp({ email, password })` with the normal client (anon key). This triggers `handle_new_user` to insert the profiles row with `role='user'`.
     2. If email verification is enabled, use the `supabase_execute_sql` tool to bypass it. Skip this step if verification is already disabled.
     3. Use the `supabase_execute_sql` tool to promote the user to admin in the profiles table. Do NOT ask the user to change the role manually.
     Example script pattern:
     ```javascript
     // Step 1: Register with anon key
     const { data: authData } = await supabase.auth.signUp({ email: `${username}@miaoda.com`, password });
     ```
     Step 2: If verification is enabled, use the `supabase_execute_sql` tool to bypass it:
     ```sql
     UPDATE auth.users SET email_confirmed_at = NOW(), confirmed_at = NOW() WHERE email = '<username>@miaoda.com';
     ```
     Step 3: Use the `supabase_execute_sql` tool to promote the user to admin:
     ```sql
     UPDATE public.profiles SET role = 'admin' WHERE email = '<username>@miaoda.com';
     ```
   - The script must be executed automatically as part of the setup; log the resulting credentials (username + password) to the console.

   **B. Email + Password login (when user explicitly requests)**:
   - AI must create one example admin account using a real email format and a randomly generated, strong password (16+ chars, mixed case + digits + symbols). Never use simple passwords unless the user explicitly specifies one. Output the credentials in the finish summary.
   - **TIMING: Execute the three steps below immediately after the auth migration runs — do NOT defer to the end of the task.**
   - Account creation flow (three-step, fully automated via script):
     1. Register using the anon key: call `supabase.auth.signUp({ email, password })` with the normal client (anon key). This triggers `handle_new_user` to insert the profiles row with `role='user'`.
     2. If email verification is enabled, use the `supabase_execute_sql` tool to bypass it. Skip this step if verification is already disabled.
     3. Use the `supabase_execute_sql` tool to promote the user to admin in the profiles table.
     Example script pattern:
     ```javascript
     // Step 1: Register with anon key
     const { data: authData } = await supabase.auth.signUp({ email: `admin@example.com`, password });
     ```
     Step 2: If verification is enabled, use the `supabase_execute_sql` tool to bypass it:
     ```sql
     UPDATE auth.users SET email_confirmed_at = NOW(), confirmed_at = NOW() WHERE email = 'admin@example.com';
     ```
     Step 3: Use the `supabase_execute_sql` tool to promote the user to admin:
     ```sql
     UPDATE public.profiles SET role = 'admin' WHERE email = 'admin@example.com';
     ```
   - The script must be executed automatically as part of the setup; log the resulting credentials (email + password) to the console.

   **Common rules for both methods**:
   - After login, check the user's role from profiles and conditionally show admin navigation entries (e.g. an "Admin" tab or header icon). Do NOT create a separate admin login route — admin uses the same login screen as regular users, and the app routes by role after authentication.
   - Admin page: manage user roles (edit others)
   - Profiles permissions:
     1. Create helper `get_user_role` (SECURITY DEFINER) to prevent infinite recursion detected in policy for relation "profiles"
     2. Admins have full access
     3. Users can view own data
     4. Users can edit own data except `role`
     5. Use `public_profiles` view for shareable info
     Here is an example:
     ```sql
     CREATE OR REPLACE FUNCTION get_user_role(uid uuid)
     RETURNS user_role
     LANGUAGE sql
     SECURITY DEFINER
     SET search_path = public
     AS $$
       SELECT role FROM profiles WHERE id = uid;
     $$;

     CREATE POLICY "Admins have full access to profiles" ON profiles
       FOR ALL TO authenticated USING (get_user_role(auth.uid()) = 'admin'::user_role);

     CREATE POLICY "Users can view their own profile" ON profiles
       FOR SELECT TO authenticated USING (auth.uid() = id);

     CREATE POLICY "Users can update their own profile" ON profiles
       FOR UPDATE TO authenticated USING (auth.uid() = id)
       WITH CHECK (role IS NOT DISTINCT FROM get_user_role(auth.uid()));

     CREATE VIEW public_profiles AS
       SELECT id, role FROM profiles;
     ```

**Recommended**:
1. If no verification is needed, auto-login after signup and navigate back
</AUTH_REQUIRED_ITEMS>

<AUTH_METHODS>
**Username + Password** (default):
- Simulate email/password with `@miaoda.com` suffix: `username@miaoda.com`
- Use `supabase_verification` tool to disable email verification
- Only letters, digits, and `_` are allowed in usernames
- Signup: `supabase.auth.signUp({ email: username + "@miaoda.com", password })`
- Login: `supabase.auth.signInWithPassword({ email: username + "@miaoda.com", password })`

**Email + Password** (when user explicitly requests):
- Use real email address directly (no suffix simulation)
- Use `supabase_verification` tool to disable email verification if needed
- Signup: `supabase.auth.signUp({ email, password })`
- Login: `supabase.auth.signInWithPassword({ email, password })`

**Phone + OTP**: **NOT supported** in the international version — do NOT implement phone login under any circumstances.
</AUTH_METHODS>

<AUTH_TOKEN_STORAGE>
**Token Storage**:
- Supabase client already configured with `expo-sqlite/localStorage/install` for session persistence (see `tech_native_supabase.j2`)
- For sensitive tokens beyond Supabase session, use `expo-secure-store`
</AUTH_TOKEN_STORAGE>

<AUTH_UI_RULES>
**Login UI Requirements**:
- MUST use React Native components (`TextInput`, `Pressable`, `Text`, `View`) — NEVER HTML elements
- MUST include User Agreement + Privacy Policy checkbox (same as other app types)
- Show loading state (`ActivityIndicator`) during auth operations
- Show meaningful error messages on auth failure (wrong password, user not found, etc.)
- Password field: use `secureTextEntry` prop with show/hide toggle

**FORBIDDEN in Mobile App Auth**:
- NEVER use `window.location`, `window.open`, or any browser API
- NEVER manually use browser `localStorage` or `AsyncStorage` for auth state — the Supabase client handles session persistence automatically via `expo-sqlite/localStorage/install`
- NEVER implement Google SSO in Phase 1
- NEVER use web-style form submission (`<form>`, `onSubmit`)
- NEVER use `@/components/common/RouteGuard.tsx` or `@/context/AuthContext.tsx` (these are Web boilerplate files)
</AUTH_UI_RULES>

<AUTH_CONSTRAINTS>
**Auth Constraints**:
1. Never run concurrent auth operations; `supabase-js` internally uses global lock for serialization
2. Add timeouts to all auth operations to prevent infinite blocking
3. Check auth state first; defer other operations until confirmed
4. Keep RLS policies fast; avoid complex queries that may hang
5. Combine `auth.users` + `profiles` for complete user information; use `userId` for profile queries
6. Prioritize `getSession()` for login status and provide global login state control
7. Logout MUST be accessible from the main app interface (see Required item 4 above) — NOT hidden in transitional or one-time pages
8. Login screen must be accessible even when not logged in (whitelist the auth route group)
9. **signUp with role selection or approval flow MUST use an Edge Function**: Two cases require wrapping `signUp` in a Supabase Edge Function (service-role key) instead of calling it directly from the frontend:
   - **Case A — role selected at registration**: When the user picks an identity/role during signup (e.g. buyer vs. seller, student vs. teacher), the Edge Function calls `supabaseAdmin.auth.admin.createUser(...)` and writes the chosen role to `profiles` atomically. NEVER call `supabase.auth.signUp()` on the frontend and then do a separate `profiles` update from client code.
   - **Case B — post-registration approval**: When the account must go through a review/approval step before activation, the Edge Function creates the user and sets `status = 'pending'`. NEVER let the frontend call `signUp` and then write approval state directly.
   - In both cases the frontend only calls the Edge Function and receives a session token back; no privileged writes happen client-side.
</AUTH_CONSTRAINTS>

<AUTH_TECH_LIMITS>
**Tech Limits**:
1. Unregistered users can't set roles; must register first via signUp. The AI setup script uses the `supabase_execute_sql` tool to set admin role automatically for both username+password and email+password methods.
2. Single account system; multi-device handled by roles
3. Password changes/add accounts via Edge Functions (do not use trigger for auth→profiles)
4. Do not insert into profiles directly; only trigger sync adds rows
5. Only `profiles.id` may reference `auth.users(id)`; other tables must reference `profiles(id)`
6. Use the `supabase_verification` tool to set up verification
7. Only username in email field; no phone in email field
8. Do not allow login with both email and username — use username with `@miaoda.com` simulation
9. AI-registered or AI-created accounts must use randomly generated, strong passwords (16+ chars, mixed uppercase + lowercase + digits + symbols). Never use simple or guessable passwords unless the user explicitly specifies the password.
10. **signUp with role selection or approval flow MUST use an Edge Function**: Two cases require wrapping `signUp` in a Supabase Edge Function (service-role key) instead of calling it directly from the frontend:
    - **Case A — role selected at registration**: When the user picks an identity/role during signup (e.g. buyer vs. seller, student vs. teacher), the Edge Function calls `supabaseAdmin.auth.admin.createUser(...)` and writes the chosen role to `profiles` atomically. NEVER call `supabase.auth.signUp()` on the frontend and then do a separate `profiles` role update from client code.
    - **Case B — post-registration approval**: When the account must go through a review/approval step before activation, the Edge Function creates the user and sets `status = 'pending'`. NEVER let the frontend call `signUp` and then write approval state directly.
    - In both cases the frontend only calls the Edge Function and receives a session token back; no privileged writes happen client-side.
</AUTH_TECH_LIMITS>

<AUTH_FINISH_SUMMARY>
**Finish Summary Requirements (MANDATORY)**:
In the final reply to the user, you MUST include a summary section covering all applicable items:
1. List all login methods implemented (e.g., username-password, email-password).
2. Admin roles: output the admin account credentials (username/email + password) created by the setup script.
3. User Agreement & Privacy Policy: remind the user — "Please modify the User Agreement & Privacy Policy yourself to mitigate legal risks."
4. Verification status: if verification was disabled via `supabase_verification`, inform the user that verification is currently disabled and explain how to re-enable it.
5. Any other manual steps the user must perform (Supabase Dashboard changes, environment variable settings, etc.).
</AUTH_FINISH_SUMMARY>

</NATIVE_AUTH_REQUIREMENTS>
